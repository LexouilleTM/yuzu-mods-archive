Super Mario Odyssey - Clean UI, v 1.01
========================================
By: Eloeri
========================================

Instructions:

1. Extract contents of .zip directly onto SD card. 

2. Enjoy!